from django import forms
from .models import ClothingRecommendation

class ClothingRecommendationForm(forms.ModelForm):
    class Meta:
        model = ClothingRecommendation
        fields = ['upper_wear', 'under_wear', 'image', 'min_score']
        labels = {
            'upper_wear': '上半身',
            'under_wear': '下半身',
            'image': '画像',
            'min_score': 'Temperature score',
        }
