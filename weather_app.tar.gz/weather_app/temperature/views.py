import random
from django.shortcuts import render, redirect, get_object_or_404
from .models import ClothingRecommendation
from .forms import ClothingRecommendationForm
import requests
from lxml import etree

def get_temperatures_from_xml():
    url = "https://www.data.jma.go.jp/developer/xml/data/20240717013334_0_VPFD51_140000.xml"
    response = requests.get(url)
    xml_content = response.content
    tree = etree.fromstring(xml_content)
    
    max_temp = tree.xpath('//jmx_eb:Temperature[@type="日中の最高気温"]/text()', namespaces={'jmx_eb': 'http://xml.kishou.go.jp/jmaxml1/elementBasis1/'} )
    min_temp = tree.xpath('//jmx_eb:Temperature[@type="朝の最低気温"]/text()', namespaces={'jmx_eb': 'http://xml.kishou.go.jp/jmaxml1/elementBasis1/'} )

    return int(max_temp[0]), int(min_temp[0])

def get_recommendation(min_score, max_score, upper_wear):
    recommendations = ClothingRecommendation.objects.filter(
        min_score__gte=min_score,
        min_score__lte=max_score,
        upper_wear=upper_wear
    )
    if recommendations.exists():
        return random.choice(recommendations)
    return None

def index(request):
    max_temp, min_temp = get_temperatures_from_xml()

    if max_temp >= 30:
        upper_recommendation = get_recommendation(90, 100, True)
        lower_recommendation = get_recommendation(90, 100, False)
    elif max_temp >= 25:
        upper_recommendation = get_recommendation(70, 89, True)
        lower_recommendation = get_recommendation(70, 89, False)
    elif max_temp >= 20:
        upper_recommendation = get_recommendation(50, 69, True)
        lower_recommendation = get_recommendation(50, 69, False)
    else:
        upper_recommendation = get_recommendation(0, 49, True)
        lower_recommendation = get_recommendation(0, 49, False)

    return render(request, 'temperature/index.html', {
        'upper_recommendation': upper_recommendation,
        'lower_recommendation': lower_recommendation,
        'max_temp': max_temp,
        'min_temp': min_temp
    })

def add_clothing(request):
    if request.method == 'POST':
        form = ClothingRecommendationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = ClothingRecommendationForm()
    return render(request, 'temperature/add_clothing.html', {'form': form})

def manage_clothing(request):
    recommendations = ClothingRecommendation.objects.all()
    return render(request, 'temperature/manage_clothing.html', {'recommendations': recommendations})

def delete_clothing(request, pk):
    recommendation = get_object_or_404(ClothingRecommendation, pk=pk)
    if request.method == 'POST':
        recommendation.delete()
        return redirect('manage_clothing')
    return render(request, 'temperature/delete_clothing.html', {'recommendation': recommendation})
