from django.db import models

class UserInput(models.Model):
    photo = models.ImageField(upload_to='photos/')
    temperature_score = models.IntegerField()

    def __str__(self):
        return f'Score: {self.temperature_score}'

class ClothingRecommendation(models.Model):
    upper_wear = models.BooleanField(default=True)  # True for 上半身
    under_wear = models.BooleanField(default=False)  # True for 下半身
    image = models.ImageField(upload_to='clothing/', default='default_image.jpg')
    min_score = models.IntegerField(verbose_name="Temperature score")

    def __str__(self):
        parts = []
        if self.upper_wear:
            parts.append("上半身")
        if self.under_wear:
            parts.append("下半身")
        parts_str = "と".join(parts) if parts else "Unknown"
        return f'{parts_str} (Temperature score: {self.min_score})'
