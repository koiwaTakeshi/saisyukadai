from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add/', views.add_clothing, name='add_clothing'),
    path('manage/', views.manage_clothing, name='manage_clothing'),
    path('delete/<int:pk>/', views.delete_clothing, name='delete_clothing'),
]
